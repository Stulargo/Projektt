﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.obliczenieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.figuryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.poleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kołoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prostokątToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obwódToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kwadratToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kołoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bryłyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.objętośćToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.walecToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stożekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polePowierzchniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kulaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quizToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rozwiążQuizToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sprawdźNazwiskoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.koloryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interpretacjaGeometrycznaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.figuryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bryłyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.kołoToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.prostokatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obliczenieToolStripMenuItem,
            this.quizToolStripMenuItem,
            this.koloryToolStripMenuItem,
            this.interpretacjaGeometrycznaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // obliczenieToolStripMenuItem
            // 
            this.obliczenieToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.figuryToolStripMenuItem,
            this.bryłyToolStripMenuItem});
            this.obliczenieToolStripMenuItem.Name = "obliczenieToolStripMenuItem";
            this.obliczenieToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.obliczenieToolStripMenuItem.Text = "Obliczenie";
            // 
            // figuryToolStripMenuItem
            // 
            this.figuryToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.poleToolStripMenuItem,
            this.obwódToolStripMenuItem});
            this.figuryToolStripMenuItem.Name = "figuryToolStripMenuItem";
            this.figuryToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.figuryToolStripMenuItem.Text = "Figury";
            // 
            // poleToolStripMenuItem
            // 
            this.poleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kołoToolStripMenuItem,
            this.prostokątToolStripMenuItem});
            this.poleToolStripMenuItem.Name = "poleToolStripMenuItem";
            this.poleToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.poleToolStripMenuItem.Text = "Pole";
            // 
            // kołoToolStripMenuItem
            // 
            this.kołoToolStripMenuItem.Name = "kołoToolStripMenuItem";
            this.kołoToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.kołoToolStripMenuItem.Text = "Koło";
            this.kołoToolStripMenuItem.Click += new System.EventHandler(this.kołoToolStripMenuItem_Click);
            // 
            // prostokątToolStripMenuItem
            // 
            this.prostokątToolStripMenuItem.Name = "prostokątToolStripMenuItem";
            this.prostokątToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.prostokątToolStripMenuItem.Text = "Prostokąt";
            this.prostokątToolStripMenuItem.Click += new System.EventHandler(this.prostokątToolStripMenuItem_Click);
            // 
            // obwódToolStripMenuItem
            // 
            this.obwódToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kwadratToolStripMenuItem,
            this.kołoToolStripMenuItem1});
            this.obwódToolStripMenuItem.Name = "obwódToolStripMenuItem";
            this.obwódToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.obwódToolStripMenuItem.Text = "Obwód";
            // 
            // kwadratToolStripMenuItem
            // 
            this.kwadratToolStripMenuItem.Name = "kwadratToolStripMenuItem";
            this.kwadratToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.kwadratToolStripMenuItem.Text = "Kwadrat";
            this.kwadratToolStripMenuItem.Click += new System.EventHandler(this.kwadratToolStripMenuItem_Click);
            // 
            // kołoToolStripMenuItem1
            // 
            this.kołoToolStripMenuItem1.Name = "kołoToolStripMenuItem1";
            this.kołoToolStripMenuItem1.Size = new System.Drawing.Size(117, 22);
            this.kołoToolStripMenuItem1.Text = "Koło";
            this.kołoToolStripMenuItem1.Click += new System.EventHandler(this.kołoToolStripMenuItem1_Click);
            // 
            // bryłyToolStripMenuItem
            // 
            this.bryłyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.objętośćToolStripMenuItem,
            this.polePowierzchniToolStripMenuItem});
            this.bryłyToolStripMenuItem.Name = "bryłyToolStripMenuItem";
            this.bryłyToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.bryłyToolStripMenuItem.Text = "Bryły";
            // 
            // objętośćToolStripMenuItem
            // 
            this.objętośćToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.walecToolStripMenuItem,
            this.stożekToolStripMenuItem});
            this.objętośćToolStripMenuItem.Name = "objętośćToolStripMenuItem";
            this.objętośćToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.objętośćToolStripMenuItem.Text = "Objętość";
            // 
            // walecToolStripMenuItem
            // 
            this.walecToolStripMenuItem.Name = "walecToolStripMenuItem";
            this.walecToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.walecToolStripMenuItem.Text = "Walec";
            this.walecToolStripMenuItem.Click += new System.EventHandler(this.walecToolStripMenuItem_Click);
            // 
            // stożekToolStripMenuItem
            // 
            this.stożekToolStripMenuItem.Name = "stożekToolStripMenuItem";
            this.stożekToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.stożekToolStripMenuItem.Text = "Stożek";
            this.stożekToolStripMenuItem.Click += new System.EventHandler(this.stożekToolStripMenuItem_Click);
            // 
            // polePowierzchniToolStripMenuItem
            // 
            this.polePowierzchniToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kulaToolStripMenuItem});
            this.polePowierzchniToolStripMenuItem.Name = "polePowierzchniToolStripMenuItem";
            this.polePowierzchniToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.polePowierzchniToolStripMenuItem.Text = "Pole Powierzchni";
            // 
            // kulaToolStripMenuItem
            // 
            this.kulaToolStripMenuItem.Name = "kulaToolStripMenuItem";
            this.kulaToolStripMenuItem.Size = new System.Drawing.Size(97, 22);
            this.kulaToolStripMenuItem.Text = "Kula";
            this.kulaToolStripMenuItem.Click += new System.EventHandler(this.kulaToolStripMenuItem_Click);
            // 
            // quizToolStripMenuItem
            // 
            this.quizToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rozwiążQuizToolStripMenuItem,
            this.sprawdźNazwiskoToolStripMenuItem});
            this.quizToolStripMenuItem.Name = "quizToolStripMenuItem";
            this.quizToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.quizToolStripMenuItem.Text = "Quiz";
            // 
            // rozwiążQuizToolStripMenuItem
            // 
            this.rozwiążQuizToolStripMenuItem.Name = "rozwiążQuizToolStripMenuItem";
            this.rozwiążQuizToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.rozwiążQuizToolStripMenuItem.Text = "Rozwiąż quiz";
            this.rozwiążQuizToolStripMenuItem.Click += new System.EventHandler(this.rozwiążQuizToolStripMenuItem_Click);
            // 
            // sprawdźNazwiskoToolStripMenuItem
            // 
            this.sprawdźNazwiskoToolStripMenuItem.Name = "sprawdźNazwiskoToolStripMenuItem";
            this.sprawdźNazwiskoToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.sprawdźNazwiskoToolStripMenuItem.Text = "Sprawdź nazwisko";
            this.sprawdźNazwiskoToolStripMenuItem.Click += new System.EventHandler(this.sprawdźNazwiskoToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "label2";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 46);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(12, 108);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 149);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Oblicz";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(9, 231);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 215);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(155)))), ((int)(((byte)(204)))));
            this.label4.Font = new System.Drawing.Font("Noto Sans", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label4.Location = new System.Drawing.Point(191, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(478, 73);
            this.label4.TabIndex = 8;
            this.label4.Text = "Quiz Matematyczny";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(186, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Pytanie 1.: ile jest równe sin²α + cos²α";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(6, 34);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(578, 20);
            this.textBox4.TabIndex = 10;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 178);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 11;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(137, 82);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(596, 346);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " ";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(119)))), ((int)(((byte)(221)))), ((int)(((byte)(119)))));
            this.button3.Location = new System.Drawing.Point(221, 305);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(119, 23);
            this.button3.TabIndex = 13;
            this.button3.Text = "Wyślij odpowiedzi";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.comboBox2);
            this.groupBox5.Location = new System.Drawing.Point(6, 232);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(584, 55);
            this.groupBox5.TabIndex = 16;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Pytanie 5.: Które z poniższych twierdzeń o trójkątach są prawdziwe? (Zaznacz wszy" +
    "stkie poprawne odpowiedzi) 1 2 i 4";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "W trójkącie równobocznym wszystkie kąty mają po 60°",
            "W trójkącie prostokątnym suma dwóch kątów ostrych wynosi 90°",
            "W trójkącie równoramiennym wszystkie boki są równe",
            "W trójkącie dowolnym suma długości dwóch boków jest większa od długości trzeciego" +
                " boku",
            "Trójkąt, którego wszystkie kąty są ostre, nazywamy rozwartokątnym"});
            this.comboBox2.Location = new System.Drawing.Point(6, 28);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(566, 21);
            this.comboBox2.TabIndex = 15;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comboBox1);
            this.groupBox4.Location = new System.Drawing.Point(6, 173);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(584, 52);
            this.groupBox4.TabIndex = 15;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Pytanie 4.: ile wynosi wartość wyrażenia 3^2+4⋅5";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "29",
            "31",
            "35",
            "49"});
            this.comboBox1.Location = new System.Drawing.Point(6, 19);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(572, 21);
            this.comboBox1.TabIndex = 14;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.checkBox5);
            this.groupBox3.Controls.Add(this.checkBox4);
            this.groupBox3.Controls.Add(this.checkBox3);
            this.groupBox3.Controls.Add(this.checkBox2);
            this.groupBox3.Controls.Add(this.checkBox1);
            this.groupBox3.Location = new System.Drawing.Point(6, 112);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(584, 55);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Pytanie 3.: które z podanych liczb są liczbami pierwszymi (wybierz wszystkie popr" +
    "awne)";
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(161, 32);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(38, 17);
            this.checkBox5.TabIndex = 4;
            this.checkBox5.Text = "11";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(123, 32);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(32, 17);
            this.checkBox4.TabIndex = 3;
            this.checkBox4.Text = "9";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(83, 32);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(32, 17);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "7";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(45, 32);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(32, 17);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "4";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(7, 32);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(32, 17);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "2";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Location = new System.Drawing.Point(6, 60);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(584, 46);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Pytanie 2.: do obliczenia pola koła potrzebujemy średnicy";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(123, 20);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(61, 17);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "Prawda";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(7, 20);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(51, 17);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.Text = "Fałsz";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // koloryToolStripMenuItem
            // 
            this.koloryToolStripMenuItem.Name = "koloryToolStripMenuItem";
            this.koloryToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.koloryToolStripMenuItem.Text = "Kolory";
            // 
            // interpretacjaGeometrycznaToolStripMenuItem
            // 
            this.interpretacjaGeometrycznaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.figuryToolStripMenuItem1,
            this.bryłyToolStripMenuItem1});
            this.interpretacjaGeometrycznaToolStripMenuItem.Name = "interpretacjaGeometrycznaToolStripMenuItem";
            this.interpretacjaGeometrycznaToolStripMenuItem.Size = new System.Drawing.Size(163, 20);
            this.interpretacjaGeometrycznaToolStripMenuItem.Text = "Interpretacja geometryczna";
            // 
            // figuryToolStripMenuItem1
            // 
            this.figuryToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kołoToolStripMenuItem2,
            this.prostokatToolStripMenuItem});
            this.figuryToolStripMenuItem1.Name = "figuryToolStripMenuItem1";
            this.figuryToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.figuryToolStripMenuItem1.Text = "Figury";
            // 
            // bryłyToolStripMenuItem1
            // 
            this.bryłyToolStripMenuItem1.Name = "bryłyToolStripMenuItem1";
            this.bryłyToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.bryłyToolStripMenuItem1.Text = "Bryły";
            // 
            // kołoToolStripMenuItem2
            // 
            this.kołoToolStripMenuItem2.Name = "kołoToolStripMenuItem2";
            this.kołoToolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.kołoToolStripMenuItem2.Text = "Koło";
            // 
            // prostokatToolStripMenuItem
            // 
            this.prostokatToolStripMenuItem.Name = "prostokatToolStripMenuItem";
            this.prostokatToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.prostokatToolStripMenuItem.Text = "Prostokat";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Matematyka";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem obliczenieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem figuryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem poleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kołoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obwódToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bryłyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prostokątToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem objętośćToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem walecToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stożekToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polePowierzchniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kulaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kwadratToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kołoToolStripMenuItem1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripMenuItem quizToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rozwiążQuizToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sprawdźNazwiskoToolStripMenuItem;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ToolStripMenuItem koloryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem interpretacjaGeometrycznaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem figuryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem kołoToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem prostokatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bryłyToolStripMenuItem1;
    }
}

